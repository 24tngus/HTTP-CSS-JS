
 export class Person{
	 constructor(n){
		 this.name = n;
	 }
 }
 
 export function aaa(){
	 console.log("hello");
 }
 
