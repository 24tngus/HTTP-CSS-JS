
 export default function bbb(){
	 console.log("world");
 }
 
 export const MAX_VALUE = 9999;