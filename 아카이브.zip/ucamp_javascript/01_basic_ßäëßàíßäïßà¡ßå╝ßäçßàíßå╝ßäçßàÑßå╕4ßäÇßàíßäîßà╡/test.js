//test.js

document.write("안녕하세요");
console.log("감사합니다.");